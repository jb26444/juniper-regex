run reg_10.py
